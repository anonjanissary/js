package scraper

import (
	"crypto/tls"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
	"time"
)

func ScrapeSomeProxies() {
	client := new(http.Client)
	client.Transport = &http.Transport{
		ForceAttemptHTTP2: true,
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
		},
	}

	client.Timeout = 5 * time.Second
	reader := new(io.ReadCloser)

	req, err := http.NewRequest("GET", "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http,https=timeout=10000&country=all&ssl=all&anonymity=all", *reader)
	if err != nil {
		fmt.Printf("[Request failed] - %s\n", err.Error())
		return
	}

	resp, err := client.Do(req)
	if err != nil {
		fmt.Printf("[Obtaining response failed] - %s\n", err.Error())
		return
	}

	content, err := ioutil.ReadAll(resp.Body)
	if err != nil && err != io.EOF {
		return
	}

	proxylist := strings.TrimSpace(string(content))
	file, err := os.OpenFile("proxy.txt", os.O_CREATE|os.O_TRUNC, 0644)

	if err != nil {
		return
	}
	defer file.Close()
	_, _ = file.WriteString(proxylist)
}
